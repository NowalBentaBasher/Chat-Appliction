# Chat-Application
This is a simple chat application implemented in Java using sockets. It has a simple GUI implemented in Swing.
